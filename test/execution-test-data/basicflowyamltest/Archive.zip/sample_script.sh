echo "This is a bash script."
