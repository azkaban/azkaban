DROP TABLE ${schema_name}.${table_name}
