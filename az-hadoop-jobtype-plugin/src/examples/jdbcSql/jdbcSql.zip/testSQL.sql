CREATE TABLE ${schema_name}.${table_name} 
(id integer primary key, name varchar(100), code integer)
-- insert into ${schema_name}.${table_name}   