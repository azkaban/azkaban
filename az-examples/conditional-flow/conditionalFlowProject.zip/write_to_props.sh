echo '{"param1": "1"}' > $JOB_OUTPUT_PROP_FILE

