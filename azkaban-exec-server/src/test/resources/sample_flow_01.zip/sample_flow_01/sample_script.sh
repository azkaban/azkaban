#!/usr/bin/env bash
echo "My pid is $$"
pwd
echo "sample text" > sample.test.txt
